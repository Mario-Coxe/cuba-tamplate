import { Component } from '@angular/core';

@Component({
  selector: 'app-balance-profile',
  templateUrl: './balance-profile.component.html',
  styleUrls: ['./balance-profile.component.scss']
})
export class BalanceProfileComponent {

}
