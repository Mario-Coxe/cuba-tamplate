import { Component } from '@angular/core';

@Component({
  selector: 'app-crypto-right-content',
  templateUrl: './crypto-right-content.component.html',
  styleUrls: ['./crypto-right-content.component.scss']
})
export class CryptoRightContentComponent {

}
