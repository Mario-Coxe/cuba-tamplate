import { Component } from '@angular/core';

@Component({
  selector: 'app-online-course',
  templateUrl: './online-course.component.html',
  styleUrls: ['./online-course.component.scss']
})
export class OnlineCourseComponent {

  constructor() {}
}
