import { Component } from '@angular/core';

@Component({
  selector: 'app-social-user-profile',
  templateUrl: './social-user-profile.component.html',
  styleUrls: ['./social-user-profile.component.scss']
})
export class SocialUserProfileComponent {

}
