import { Component } from '@angular/core';

@Component({
  selector: 'app-mobile-application',
  templateUrl: './mobile-application.component.html',
  styleUrls: ['./mobile-application.component.scss']
})
export class MobileApplicationComponent {

}
