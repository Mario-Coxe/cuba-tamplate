import { Component } from '@angular/core';

@Component({
  selector: 'app-purchase-account',
  templateUrl: './purchase-account.component.html',
  styleUrls: ['./purchase-account.component.scss']
})
export class PurchaseAccountComponent {

}
