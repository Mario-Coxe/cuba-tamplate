import { Component } from '@angular/core';

@Component({
  selector: 'app-paper-note',
  templateUrl: './paper-note.component.html',
  styleUrls: ['./paper-note.component.scss']
})
export class PaperNoteComponent {

}
