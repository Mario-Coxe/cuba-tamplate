import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-color-tab',
  templateUrl: './color-tab.component.html',
  styleUrls: ['./color-tab.component.scss']
})
export class ColorTabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
