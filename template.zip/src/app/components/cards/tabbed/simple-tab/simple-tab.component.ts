import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-tab',
  templateUrl: './simple-tab.component.html',
  styleUrls: ['./simple-tab.component.scss']
})
export class SimpleTabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
