import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edge',
  templateUrl: './edge.component.html',
  styleUrls: ['./edge.component.scss']
})
export class EdgeComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
