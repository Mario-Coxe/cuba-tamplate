import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mega-options',
  templateUrl: './mega-options.component.html',
  styleUrls: ['./mega-options.component.scss']
})
export class MegaOptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
